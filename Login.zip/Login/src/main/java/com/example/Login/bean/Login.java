package com.example.Login.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="login")

public class Login
{
	@Id
	@GeneratedValue
	private int login_id;
	private String name;
	private int phone;
	public void setLogin_id(int login_id) {
		this.login_id = login_id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public int getLogin_id() {
		return login_id;
	}
	public String getName() {
		return name;
	}
	public int getPhone() {
		return phone;
	}
	
}
